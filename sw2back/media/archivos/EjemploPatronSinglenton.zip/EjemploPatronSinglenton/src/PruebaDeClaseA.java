public class PruebaDeClaseA {
    
    public static void main(String[] args) {
        ClaseA obj1 =  ClaseA.getInstance();
        ClaseA obj2 = ClaseA.getInstance();
        ClaseA obj3 = ClaseA.getInstance();
        
        if (obj1==obj3){
            System.out.println("Son iguales");
        }else{
            System.out.println("Son diferentes");
        }
        
    }
        
}
