public class ClaseA {
    //(1) Declarar un atributo de clase del mismo tipo
    // de la clase
    private static ClaseA instance;
    // (2) Hacer que el constructor por 
    // default u otros
    // sean de acceso privado
    private ClaseA(){
        
    }
    // (3) Crear un metodo estatico que cree y 
    // devuelva la una instancia u objeto de la
    // clase
    public static ClaseA getInstance(){
        if (instance==null){
            instance = new ClaseA();
        }
        return instance;
    }
    // Atributos
    
    // metodos
}
