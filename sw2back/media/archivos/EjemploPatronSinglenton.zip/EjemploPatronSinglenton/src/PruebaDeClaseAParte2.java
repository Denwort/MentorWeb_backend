public class PruebaDeClaseAParte2 {
    
    public static void main(String[] args) {
//        while (true){
//            ClaseA obj2 = new ClaseA(); 
//            System.out.println("Se creo una instancia de clase A");
//        }
    }
    
}
