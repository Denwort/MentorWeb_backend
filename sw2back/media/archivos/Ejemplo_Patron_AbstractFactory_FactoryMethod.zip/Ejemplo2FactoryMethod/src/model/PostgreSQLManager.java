package model;

public class PostgreSQLManager extends DBManager {

    @Override
    public Database newDatabase() {
        return new PostgreSQL();
    }
    
}
