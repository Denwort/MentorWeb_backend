package model;

// concreteCreator
public class MySQLManager extends DBManager{

    @Override
    public Database newDatabase() {
        return new MySQL();
    }
    
}
