package model;
// Creator
public abstract class DBManager {
    // factoryMethod
    public abstract Database newDatabase();
    
}
