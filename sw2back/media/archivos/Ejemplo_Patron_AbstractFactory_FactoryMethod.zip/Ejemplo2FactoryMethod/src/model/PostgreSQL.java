package model;

public class PostgreSQL extends Database{

    @Override
    public void openConnection() {
        System.out.println("Open posgresql");
    }

    @Override
    public void closeConnection() {
        System.out.println("Close posgresql");
    }
    
}
