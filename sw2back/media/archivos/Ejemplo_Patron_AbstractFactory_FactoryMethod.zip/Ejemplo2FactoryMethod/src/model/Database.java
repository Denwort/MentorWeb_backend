package model;

// Product
public abstract class Database {
    public abstract void openConnection();
    public abstract void closeConnection();    
}
