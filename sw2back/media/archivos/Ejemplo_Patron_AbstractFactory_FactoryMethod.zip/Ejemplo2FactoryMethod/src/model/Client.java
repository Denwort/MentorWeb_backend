package model;

public class Client {

    public static void abrirConexion(DBManager gestor) {
        Database db = gestor.newDatabase();
        db.openConnection();
    }

    public static void main(String[] args) {
        String tipoBD = "MySQL";
        if (tipoBD.equals("MySQL")) {
            DBManager manager = new MySQLManager();
            abrirConexion(manager);
        } else if (tipoBD.equals("PosgreSQL")) {
            DBManager manager = new PostgreSQLManager();
            abrirConexion(manager);
        }
    }

}
