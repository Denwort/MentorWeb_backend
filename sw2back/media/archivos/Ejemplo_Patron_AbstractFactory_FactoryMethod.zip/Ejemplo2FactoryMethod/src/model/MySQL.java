package model;

// ConcreteProduct
public class MySQL extends Database {

    @Override
    public void openConnection() {
        System.out.println("Open mysql");        
    }

    @Override
    public void closeConnection() {
        System.out.println("Close mysql");        
    }
    
}
