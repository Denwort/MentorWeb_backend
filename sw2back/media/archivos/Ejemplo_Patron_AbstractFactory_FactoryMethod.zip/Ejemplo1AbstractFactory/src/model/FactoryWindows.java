package model;

public class FactoryWindows extends FactoryGUI{

    @Override
    public Button createButton() {
        return new ButtonWindows();        
    }

    @Override
    public TextField createTextField() {
        return new TextFieldWindows();
    }
    
}
