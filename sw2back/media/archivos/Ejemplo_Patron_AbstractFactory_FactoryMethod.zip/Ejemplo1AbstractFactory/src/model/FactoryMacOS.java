package model;

public class FactoryMacOS extends FactoryGUI{

    @Override
    public Button createButton() {
        return new ButtonMacOS();        
    }

    @Override
    public TextField createTextField() {
        return new TextFieldMacOS();
    }
    
}
