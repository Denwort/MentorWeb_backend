package model;

public class ButtonMacOS extends Button{

    @Override
    public void paint() {
        System.out.println("Dibujar un buton en MacoS");        
    }
    
}
