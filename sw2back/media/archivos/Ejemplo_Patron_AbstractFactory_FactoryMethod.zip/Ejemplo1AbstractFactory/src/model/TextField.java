package model;

public abstract class TextField {
    public abstract void paint();
}
