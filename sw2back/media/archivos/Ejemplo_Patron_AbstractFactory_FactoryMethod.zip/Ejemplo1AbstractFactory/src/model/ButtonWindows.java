package model;

public class ButtonWindows extends Button{

    @Override
    public void paint() {
        System.out.println("Dibujar un Boton Windows");        
    }
    
}
