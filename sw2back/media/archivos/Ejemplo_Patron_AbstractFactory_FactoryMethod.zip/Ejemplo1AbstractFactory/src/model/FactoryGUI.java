package model;
// AbstractFactory
public abstract class FactoryGUI {
    // factoryMethodPrductA
    public abstract Button createButton();
    // factoryMethodProdcutB
    public abstract TextField createTextField();
    
}
