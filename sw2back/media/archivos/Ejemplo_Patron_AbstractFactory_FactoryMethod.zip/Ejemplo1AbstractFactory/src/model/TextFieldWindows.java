package model;

public class TextFieldWindows extends TextField{

    @Override
    public void paint() {
        System.out.println("Dibujar una caja de texto Windows");        
    }
    
}
