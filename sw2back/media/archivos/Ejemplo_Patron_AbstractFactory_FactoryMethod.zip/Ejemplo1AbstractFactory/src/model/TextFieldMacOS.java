package model;

public class TextFieldMacOS extends TextField{

    @Override
    public void paint() {
        System.out.println("Dibujar una caja de texto en MacOS");        
    }
    
}
