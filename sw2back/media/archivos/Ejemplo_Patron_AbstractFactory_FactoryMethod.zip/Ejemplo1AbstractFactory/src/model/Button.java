package model;
// AbstractProductA - Button
public abstract class Button {
    public abstract void paint();
    
}
