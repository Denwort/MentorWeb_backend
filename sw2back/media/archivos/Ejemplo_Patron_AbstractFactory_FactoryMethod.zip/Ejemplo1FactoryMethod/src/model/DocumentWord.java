package model;

public class DocumentWord extends Document{
    
}
