package model;

public class Client {
    public static Document buildDocument(Application app){
        return app.newDocument();
    }    
}
