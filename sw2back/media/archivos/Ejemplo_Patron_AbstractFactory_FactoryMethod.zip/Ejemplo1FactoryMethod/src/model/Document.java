package model;
// Product
public abstract class Document {
    
}
