package model;
// ConcreteCreator
public class AppMicrosoftExcel extends Application{
    @Override
    public Document newDocument(){
        return new DocumentExcel();
    }
}
