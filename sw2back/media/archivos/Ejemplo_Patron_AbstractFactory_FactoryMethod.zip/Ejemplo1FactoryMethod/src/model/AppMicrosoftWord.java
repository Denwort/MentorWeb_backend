package model;

// ConcreteCreator
public class AppMicrosoftWord extends Application{
    @Override
    public Document newDocument(){
        // Crear un documento de Word
        return new DocumentWord(); // creacion de un objeto
    }
}
