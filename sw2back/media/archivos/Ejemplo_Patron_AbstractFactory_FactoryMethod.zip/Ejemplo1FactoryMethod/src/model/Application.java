package model;
// Creator
public abstract class Application {
    // factoryMethod
    public abstract Document newDocument();
    
}
