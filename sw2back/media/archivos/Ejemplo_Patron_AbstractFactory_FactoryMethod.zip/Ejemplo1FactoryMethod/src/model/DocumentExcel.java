package model;

public class DocumentExcel extends Document{
    
}
