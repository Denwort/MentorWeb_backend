package pregunta1.solution;

public class PruebaPension {

    public static void main(String[] args) {
        Pensionista p1
                = new PensionistaONP("1011",
                        new Fecha(10, 10, 1945),
                        new Fecha(10, 10, 1965),
                        new Fecha(10, 10, 2000), 1000, 'F', 2);
        Pensionista p2
                = new PensionistaONP("1012",
                        new Fecha(10, 10, 1945),
                        new Fecha(10, 10, 1965),
                        new Fecha(10, 10, 2000), 1000, 'F', 2);
        Pensionista p3
                = new PensionistaONP("1013",
                        new Fecha(10, 10, 1945),
                        new Fecha(10, 10, 1965),
                        new Fecha(10, 10, 2000), 1000, 'M', 2);
        Pensionista p4
                = new PensionistaAFP("1013",
                        new Fecha(10, 10, 1945),
                        new Fecha(10, 10, 1965),
                        new Fecha(10, 10, 2000), 1000, 'F', "Integra",0.10);
        // Array
        Pensionista[] lista = new Pensionista[4];
        lista[0] = p1;
        lista[1] = p2;
        lista[2] = p3;
        lista[3] = p4;
        int cant = 0;
        for (int i = 0; i < lista.length; i++) {
            if (lista[i].sexo=='F'){
                cant++;
            }
            System.out.println(lista[i]);
        }
        System.out.println("Numero de mujeres: "+cant);

    }

}
