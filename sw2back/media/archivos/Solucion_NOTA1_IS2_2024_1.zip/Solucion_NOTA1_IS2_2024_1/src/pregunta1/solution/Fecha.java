package pregunta1.solution;

import java.time.LocalDate;
import java.time.Period;

class Fecha {

    private int dia;
    private int mes;
    private int año;

    public Fecha(int dia, int mes, int año) {
        this.dia = dia;
        this.mes = mes;
        this.año = año;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    public int calcularEdad(Fecha fechaActual) {
        int edad = fechaActual.getAño() - this.año;
        if (fechaActual.getMes() < this.mes || (fechaActual.getMes() == this.mes && fechaActual.getDia() < this.dia)) {
            edad--;
        }
        return edad;
    }

    public int calcularEdad() {
        LocalDate fechaNacimiento = LocalDate.of(año, mes, dia);
        LocalDate fechaActual = LocalDate.now();
        return Period.between(fechaNacimiento, fechaActual).getYears();
    }

    public static int calcularDiferenciaEnAnios(Fecha fechaInicio, Fecha fechaFin) {
        LocalDate fecha1 = LocalDate.of(fechaInicio.getAño(), fechaInicio.getMes(), fechaInicio.getDia());
        LocalDate fecha2 = LocalDate.of(fechaFin.getAño(), fechaFin.getMes(), fechaFin.getDia());
        return Period.between(fecha1, fecha2).getYears();
    }

    @Override
    public String toString() {
        return "Fecha{" + "dia=" + dia + ", mes=" + mes + ", a\u00f1o=" + año + '}';
    }
    
}
