package pregunta1.solution;

public abstract class Pensionista {

    protected String codigo;
    protected Fecha fechaNacimiento;
    protected Fecha fechaIngreso;
    protected Fecha fechaJubilacion;
    protected double sueldoMensual;
    protected char sexo;

    public Pensionista(String codigo, Fecha fechaNacimiento, Fecha fechaIngreso, Fecha fechaJubilacion, double sueldoMensual, char sexo) {
        this.codigo = codigo;
        this.fechaIngreso = fechaIngreso;
        this.fechaNacimiento = fechaNacimiento;
        this.fechaJubilacion = fechaJubilacion;
        this.sueldoMensual = sueldoMensual;
        this.sexo = sexo;
    }

    public abstract double calcularPension();

    @Override
    public String toString() {
        return "Pensionista{" + "codigo=" + codigo + ", fechaNacimiento=" + fechaNacimiento + ", fechaIngreso=" + fechaIngreso + ", fechaJubilacion=" + fechaJubilacion + ", sueldoMensual=" + sueldoMensual + ", sexo=" + sexo + '}';
    }
    
}
