package pregunta1.solution;

public class PensionistaAFP extends Pensionista {

    private String nombreAFP;
    private double porcentajeAporte;
    private double tasaRentabilidadAnual; // en porcentaje

    public PensionistaAFP(String codigo, Fecha fechaNacimiento, Fecha fechaIngreso, Fecha fechaJubilacion, double sueldoMensual, char sexo,
            String nombreAFP,double tasaRentabilidadAnual) {
        super(codigo, fechaNacimiento, fechaIngreso, fechaJubilacion, sueldoMensual, sexo);
        this.nombreAFP = nombreAFP;
        this.porcentajeAporte = 0.13;
        this.tasaRentabilidadAnual = tasaRentabilidadAnual;
    }

    @Override
    public double calcularPension() {
        double acumulado = sueldoMensual*porcentajeAporte * (Fecha.calcularDiferenciaEnAnios(fechaIngreso, fechaJubilacion))*12;
        double montoRentabilidad = acumulado * tasaRentabilidadAnual;
        return acumulado + montoRentabilidad;
    }

    @Override
    public String toString() {
        return super.toString()+"\n"+"PensionistaAFP{" + "nombreAFP=" + nombreAFP + ", porcentajeAporte=" + porcentajeAporte + ", tasaRentabilidadAnual=" + tasaRentabilidadAnual + '}';
    }
    
    
}
