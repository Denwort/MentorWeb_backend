package pregunta1.solution;

class PensionistaONP extends Pensionista {

    private int cantidadHijos;

    public PensionistaONP(String codigo, Fecha fechaNacimiento, Fecha fechaIngreso,Fecha fechaJubilacion, double sueldoMensual, char sexo, int cantidadHijos) {
        super(codigo, fechaNacimiento, fechaIngreso, fechaJubilacion, sueldoMensual, sexo);
        this.cantidadHijos = cantidadHijos;
    }

    @Override
    public double calcularPension() {
        if (sexo == 'F' && fechaNacimiento.calcularEdad() >= 55
                || sexo == 'M' && fechaNacimiento.calcularEdad() >= 65) {
            
            int aniosTrabajados = Fecha.calcularDiferenciaEnAnios(fechaIngreso, fechaJubilacion);                        
            return sueldoMensual * 0.13 * aniosTrabajados * 12;
        } else {
            return 0;
        }
    }

    @Override
    public String toString() {
        return super.toString()+"\n"+"PensionistaONP{" + "cantidadHijos=" + cantidadHijos + '}';
    }
    
}
