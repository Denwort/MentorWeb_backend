/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pregunta3.solution;

public class SartenRecord implements Sarten {
    @Override
    public void prepararSarten() {
        System.out.println("Preparando sartén marca Record");
    }
}
