/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pregunta3.solution;

public class FabricaRecord implements JuegoDeCocinaFactory {
    @Override
    public Cacerola crearCacerola() {
        return new CacerolaRecord();
    }

    @Override
    public Olla crearOlla() {
        return new OllaRecord();
    }

    @Override
    public Sarten crearSarten() {
        return new SartenRecord();
    }
}
