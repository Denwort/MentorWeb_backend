/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pregunta3.solution;

public class CacerolaRecord implements Cacerola {
    @Override
    public void prepararCacerola() {
        System.out.println("Preparando cacerola marca Record");
    }
}
