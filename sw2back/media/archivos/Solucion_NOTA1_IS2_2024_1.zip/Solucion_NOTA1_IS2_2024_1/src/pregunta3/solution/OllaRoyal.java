/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pregunta3.solution;

public class OllaRoyal implements Olla {
    @Override
    public void prepararOlla() {
        System.out.println("Preparando olla marca Royal");
    }
}