package pregunta2.problem;

public class Curriculum {

    String tecnologia;
    Integer añosExperiencia;
    Curriculum[] lista;

    public String getTecnologia() {
        return tecnologia;
    }

    public void setTecnologia(String tecnologia) {
        this.tecnologia = tecnologia;
    }

    public Integer getAñosExperiencia() {
        return añosExperiencia;
    }

    public void setAñosExperiencia(Integer añosExperiencia) {
        this.añosExperiencia = añosExperiencia;
    }

    public Curriculum buscarCurriculum(String tecnologiaBuscada) {
        for (Curriculum curriculum : lista) {
            if (curriculum.getTecnologia().equals(tecnologiaBuscada)) {
                return curriculum;
            }
        }
        return null;
    }
}
