package pregunta2.solution;

public class Curriculum {

    private String tecnologia;
    private Integer añosExperiencia;

    public Curriculum(String tecnologia, Integer añosExperiencia) {
        this.tecnologia = tecnologia;
        this.añosExperiencia = añosExperiencia;
    }

    public String getTecnologia() {
        return tecnologia;
    }

    public Integer getAñosExperiencia() {
        return añosExperiencia;
    }
}
