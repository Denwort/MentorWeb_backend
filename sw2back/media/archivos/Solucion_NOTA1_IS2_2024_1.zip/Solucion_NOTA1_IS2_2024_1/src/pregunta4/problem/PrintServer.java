package pregunta4.problem;

public class PrintServer {

    private String printerName;

    public PrintServer(String name) {
        this.printerName = name;
    }

    public void printDocument(String document) {
        System.out.println("Impresión en la impresora " + printerName + ":");
        System.out.println(document);
    }

}
