package pregunta4.problem;

public class Prueba {

    public static void main(String[] args) {
        PrintServer printer1 = new PrintServer("Impresora 1");
        PrintServer printer2 = new PrintServer("Impresora 2");

        String document1 = "Este es el documento 1.";
        String document2 = "Este es el documento 2.";

        printer1.printDocument(document1);
        printer2.printDocument(document2);
    }

}
