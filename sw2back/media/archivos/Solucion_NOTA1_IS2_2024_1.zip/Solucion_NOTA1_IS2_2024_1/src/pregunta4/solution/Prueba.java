package pregunta4.solution;

public class Prueba {

    public static void main(String[] args) {
        PrintServer printer1 = PrintServer.getInstance("Print1");
        PrintServer printer2 = PrintServer.getInstance("Print2");

        String document1 = "Este es el documento 1.";
        String document2 = "Este es el documento 2.";

        printer1.printDocument(document1);
        printer2.printDocument(document2);
        if (printer1.equals(printer2)){
            System.out.println("Una sola Instancia!!!!");
        }else{
            System.out.println("Instancias diferentes!!!!");
        }
        
    }

}
