package pregunta4.solution;

public class PrintServer {

    private static PrintServer instance;
    private String printerName;

    private PrintServer(String name) {
        this.printerName = name;
    }

    public static PrintServer getInstance(String name) {
        if (instance == null) {
            instance = new PrintServer(name);
        }
        return instance;
    }

    public void printDocument(String document) {
        System.out.println("Impresión en la impresora " + printerName + ":");
        System.out.println(document);
    }
}